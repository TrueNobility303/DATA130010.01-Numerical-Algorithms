
clear;
clf;
n = 1024;

subplot(1,2,1);
x = linspace(-2*pi,2*pi,n);
y = sin(3 *x);
z = fft(y);
plot(x,abs(z));
title('sin(3x)');

subplot(1,2,2);
x = linspace(-12*pi,12*pi,n);
y = sin(x) + sin(128^(1/12) * x);
z = fft(y);
plot(x,abs(z));
title('sin(x) + sin(1.4983x)');
